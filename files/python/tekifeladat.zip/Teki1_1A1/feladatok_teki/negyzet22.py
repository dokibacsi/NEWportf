from turtle import *
color('black','white')
begin_fill()

for j in range(9):
    for i in range(4):
        forward(10)
        left(90)
    backward(10)
for k in range(4):
    forward(10)
    left(90)
#for i in range(10):
#egy négyzet
#forward(150)
#left(90)
#forward(150)
#left(90)
#forward(150)
#left(90)
#forward(150)
#left(90)
#irány váltás
#forward(150)

end_fill()
done()