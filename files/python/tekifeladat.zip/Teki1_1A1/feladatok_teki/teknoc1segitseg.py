from turtle import *
color('red','yellow')
backward(100)
left(100)
done()